--
-- PostgreSQL database dump
--

\restrict RokXQnUIaazLwF9LVPRDRafk4qKjyo58IqkPohyDnN6lRQv3G9c9R0CRETOpWMa

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AlertType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AlertType" AS ENUM (
    'COST_INCREASE',
    'LOW_MARGIN',
    'CASH_FLOW'
);


ALTER TYPE public."AlertType" OWNER TO postgres;

--
-- Name: CategoryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CategoryType" AS ENUM (
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public."CategoryType" OWNER TO postgres;

--
-- Name: MessageRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MessageRole" AS ENUM (
    'USER',
    'ASSISTANT'
);


ALTER TYPE public."MessageRole" OWNER TO postgres;

--
-- Name: RecommendationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RecommendationStatus" AS ENUM (
    'ACTIVE',
    'DISMISSED',
    'APPLIED'
);


ALTER TYPE public."RecommendationStatus" OWNER TO postgres;

--
-- Name: TransactionSource; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionSource" AS ENUM (
    'CHAT',
    'VOICE',
    'MANUAL'
);


ALTER TYPE public."TransactionSource" OWNER TO postgres;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TransactionType" AS ENUM (
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public."TransactionType" OWNER TO postgres;

--
-- Name: calcular_margen_mensual(text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calcular_margen_mensual(p_user_id text, p_year integer, p_month integer) RETURNS TABLE(total_income numeric, total_expense numeric, margin numeric, margin_pct numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COALESCE(SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END), 0) AS total_income,
        COALESCE(SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END), 0) AS total_expense,
        COALESCE(SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END), 0) AS margin,
        CASE
            WHEN SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) > 0
            THEN ROUND(((SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) - SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END)) / SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END) * 100)::NUMERIC, 2)
            ELSE 0
        END AS margin_pct
    FROM transactions t
    WHERE t."userId" = p_user_id
      AND EXTRACT(YEAR FROM t.date) = p_year
      AND EXTRACT(MONTH FROM t.date) = p_month;
END;
$$;


ALTER FUNCTION public.calcular_margen_mensual(p_user_id text, p_year integer, p_month integer) OWNER TO postgres;

--
-- Name: detectar_alertas(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.detectar_alertas(p_user_id text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_income NUMERIC;
    v_expense NUMERIC;
    v_margin_pct NUMERIC;
    v_prev_expense NUMERIC;
    v_cost_increase NUMERIC;
BEGIN
    SELECT
        COALESCE(SUM(CASE WHEN type = 'INCOME' THEN amount ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END), 0)
    INTO v_income, v_expense
    FROM transactions
    WHERE "userId" = p_user_id
      AND EXTRACT(YEAR FROM date) = EXTRACT(YEAR FROM NOW())
      AND EXTRACT(MONTH FROM date) = EXTRACT(MONTH FROM NOW());

    IF v_income > 0 THEN
        v_margin_pct := ((v_income - v_expense) / v_income) * 100;
    ELSE
        v_margin_pct := 0;
    END IF;

    SELECT COALESCE(SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END), 0)
    INTO v_prev_expense
    FROM transactions
    WHERE "userId" = p_user_id
      AND EXTRACT(YEAR FROM date) = EXTRACT(YEAR FROM NOW() - INTERVAL '1 month')
      AND EXTRACT(MONTH FROM date) = EXTRACT(MONTH FROM NOW() - INTERVAL '1 month');

    IF v_prev_expense > 0 THEN
        v_cost_increase := ((v_expense - v_prev_expense) / v_prev_expense) * 100;
    ELSE
        v_cost_increase := 0;
    END IF;

    IF v_cost_increase > 15 THEN
        INSERT INTO alerts (id, "userId", message, type, "isRead", "createdAt")
        VALUES (gen_random_uuid(), p_user_id, 'Alerta: Los costos aumentaron ' || ROUND(v_cost_increase::NUMERIC, 1) || '% respecto al mes anterior.', 'COST_INCREASE', false, NOW());
    END IF;

    IF v_margin_pct < 20 THEN
        INSERT INTO alerts (id, "userId", message, type, "isRead", "createdAt")
        VALUES (gen_random_uuid(), p_user_id, 'Alerta: Tu margen de ganancia es ' || ROUND(v_margin_pct::NUMERIC, 1) || '%, por debajo del 20% recomendado.', 'LOW_MARGIN', false, NOW());
    END IF;

    IF (v_income - v_expense) < 0 THEN
        INSERT INTO alerts (id, "userId", message, type, "isRead", "createdAt")
        VALUES (gen_random_uuid(), p_user_id, 'Alerta: Tu flujo de caja es negativo este mes. Gastos superan ingresos por ' || ROUND(ABS(v_income - v_expense)::NUMERIC, 2), 'NEGATIVE_CASH_FLOW', false, NOW());
    END IF;
END;
$$;


ALTER FUNCTION public.detectar_alertas(p_user_id text) OWNER TO postgres;

--
-- Name: generar_resumen_mensual(text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generar_resumen_mensual(p_user_id text, p_year integer, p_month integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO monthly_summaries ("userId", "categoryId", year, month, "totalAmount", "transactionCount", "avgAmount")
    SELECT
        t."userId",
        t."categoryId",
        p_year,
        p_month,
        SUM(t.amount),
        COUNT(*)::INT,
        ROUND((SUM(t.amount) / COUNT(*))::NUMERIC, 2)
    FROM transactions t
    WHERE t."userId" = p_user_id
      AND EXTRACT(YEAR FROM t.date) = p_year
      AND EXTRACT(MONTH FROM t.date) = p_month
    GROUP BY t."userId", t."categoryId"
    ON CONFLICT ("userId", "categoryId", year, month)
    DO UPDATE SET
        "totalAmount" = EXCLUDED."totalAmount",
        "transactionCount" = EXCLUDED."transactionCount",
        "avgAmount" = EXCLUDED."avgAmount";
END;
$$;


ALTER FUNCTION public.generar_resumen_mensual(p_user_id text, p_year integer, p_month integer) OWNER TO postgres;

--
-- Name: obtener_balance_actual(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_balance_actual(p_user_id text) RETURNS TABLE(income double precision, expense double precision, balance double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COALESCE(SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END), 0) AS income,
        COALESCE(SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END), 0) AS expense,
        COALESCE(SUM(CASE WHEN t.type = 'INCOME' THEN t.amount ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN t.type = 'EXPENSE' THEN t.amount ELSE 0 END), 0) AS balance
    FROM transactions t
    WHERE t."userId" = p_user_id
      AND EXTRACT(YEAR FROM t.date) = EXTRACT(YEAR FROM NOW())
      AND EXTRACT(MONTH FROM t.date) = EXTRACT(MONTH FROM NOW());
END;
$$;


ALTER FUNCTION public.obtener_balance_actual(p_user_id text) OWNER TO postgres;

--
-- Name: refresh_materialized_views(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.refresh_materialized_views() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW resumen_financiero_mensual;
    REFRESH MATERIALIZED VIEW gastos_por_categoria;
    REFRESH MATERIALIZED VIEW tendencia_semanal;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.refresh_materialized_views() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_messages (
    id text NOT NULL,
    "userId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agent_messages OWNER TO postgres;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id text NOT NULL,
    "userId" text NOT NULL,
    message text NOT NULL,
    type public."AlertType" NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    type public."CategoryType" NOT NULL,
    color text DEFAULT '#3B82F6'::text NOT NULL,
    icon text DEFAULT 'tag'::text NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text NOT NULL,
    type public."TransactionType" NOT NULL,
    amount double precision NOT NULL,
    note text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source public."TransactionSource" DEFAULT 'MANUAL'::public."TransactionSource" NOT NULL,
    "rawText" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: gastos_por_categoria; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.gastos_por_categoria AS
 SELECT t."userId",
    c.name AS "categoryName",
    sum(t.amount) AS "totalAmount",
    round((((sum(t.amount) / NULLIF(totals.total, (0)::double precision)) * (100)::double precision))::numeric, 2) AS percentage,
    (count(*))::integer AS "transactionCount"
   FROM ((public.transactions t
     JOIN public.categories c ON ((t."categoryId" = c.id)))
     JOIN ( SELECT transactions."userId",
            sum(transactions.amount) AS total
           FROM public.transactions
          WHERE (transactions.type = 'EXPENSE'::public."TransactionType")
          GROUP BY transactions."userId") totals ON ((t."userId" = totals."userId")))
  WHERE (t.type = 'EXPENSE'::public."TransactionType")
  GROUP BY t."userId", c.name, totals.total
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.gastos_por_categoria OWNER TO postgres;

--
-- Name: monthly_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monthly_summaries (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    "totalAmount" double precision NOT NULL,
    "transactionCount" integer NOT NULL,
    "avgAmount" double precision NOT NULL
);


ALTER TABLE public.monthly_summaries OWNER TO postgres;

--
-- Name: monthly_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monthly_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.monthly_summaries_id_seq OWNER TO postgres;

--
-- Name: monthly_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monthly_summaries_id_seq OWNED BY public.monthly_summaries.id;


--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommendations (
    id text NOT NULL,
    "userId" text NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "suggestedPrice" double precision NOT NULL,
    "currentPrice" double precision NOT NULL,
    "variationPct" double precision NOT NULL,
    status public."RecommendationStatus" DEFAULT 'ACTIVE'::public."RecommendationStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.recommendations OWNER TO postgres;

--
-- Name: resumen_financiero_mensual; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.resumen_financiero_mensual AS
 SELECT "userId",
    (EXTRACT(year FROM date))::integer AS year,
    (EXTRACT(month FROM date))::integer AS month,
    sum(
        CASE
            WHEN (type = 'INCOME'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END) AS "totalIncome",
    sum(
        CASE
            WHEN (type = 'EXPENSE'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END) AS "totalExpense",
    (sum(
        CASE
            WHEN (type = 'INCOME'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END) - sum(
        CASE
            WHEN (type = 'EXPENSE'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END)) AS margin,
        CASE
            WHEN (sum(
            CASE
                WHEN (type = 'INCOME'::public."TransactionType") THEN amount
                ELSE (0)::double precision
            END) > (0)::double precision) THEN round(((((sum(
            CASE
                WHEN (type = 'INCOME'::public."TransactionType") THEN amount
                ELSE (0)::double precision
            END) - sum(
            CASE
                WHEN (type = 'EXPENSE'::public."TransactionType") THEN amount
                ELSE (0)::double precision
            END)) / sum(
            CASE
                WHEN (type = 'INCOME'::public."TransactionType") THEN amount
                ELSE (0)::double precision
            END)) * (100)::double precision))::numeric, 2)
            ELSE (0)::numeric
        END AS "marginPct"
   FROM public.transactions t
  GROUP BY "userId", (EXTRACT(year FROM date)), (EXTRACT(month FROM date))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.resumen_financiero_mensual OWNER TO postgres;

--
-- Name: tendencia_semanal; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.tendencia_semanal AS
 SELECT "userId",
    (date_trunc('week'::text, date))::date AS "weekStart",
    ((date_trunc('week'::text, date) + '6 days'::interval))::date AS "weekEnd",
    sum(
        CASE
            WHEN (type = 'INCOME'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END) AS income,
    sum(
        CASE
            WHEN (type = 'EXPENSE'::public."TransactionType") THEN amount
            ELSE (0)::double precision
        END) AS expense
   FROM public.transactions t
  GROUP BY "userId", (date_trunc('week'::text, date))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.tendencia_semanal OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "businessType" text NOT NULL,
    "targetMarginPct" double precision DEFAULT 40 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: monthly_summaries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_summaries ALTER COLUMN id SET DEFAULT nextval('public.monthly_summaries_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_messages (id, "userId", role, content, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, "userId", message, type, "isRead", "createdAt") FROM stdin;
dd5d820a-b787-45c8-865b-9c32f83b1ff0	604239e2-269e-4b2c-8d1e-7df5c84249dc	Tus gastos en insumos subieron un 20%	COST_INCREASE	f	2026-05-17 01:07:05.805
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, "userId", name, type, color, icon) FROM stdin;
8ce20828-2110-4a57-8894-d9708721ca3a	604239e2-269e-4b2c-8d1e-7df5c84249dc	Ventas	INCOME	#22C55E	dollar-sign
7d4c2084-bbc6-4ce8-bd3d-e4ef83b3c886	604239e2-269e-4b2c-8d1e-7df5c84249dc	Insumos	EXPENSE	#EF4444	shopping-cart
4ef49235-a534-49b5-ba56-ac6a79708665	604239e2-269e-4b2c-8d1e-7df5c84249dc	Servicios	EXPENSE	#F59E0B	zap
\.


--
-- Data for Name: monthly_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monthly_summaries (id, "userId", "categoryId", year, month, "totalAmount", "transactionCount", "avgAmount") FROM stdin;
1	604239e2-269e-4b2c-8d1e-7df5c84249dc	8ce20828-2110-4a57-8894-d9708721ca3a	2026	5	5500	3	1833.33
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommendations (id, "userId", "categoryId", title, description, "suggestedPrice", "currentPrice", "variationPct", status, "createdAt") FROM stdin;
99881480-fc2b-4730-8e3f-937714271c7f	604239e2-269e-4b2c-8d1e-7df5c84249dc	7d4c2084-bbc6-4ce8-bd3d-e4ef83b3c886	Reducir costo de insumos	Buscar proveedores alternativos	680	800	-15	ACTIVE	2026-05-17 01:07:05.794
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, "userId", "categoryId", type, amount, note, date, source, "rawText", "createdAt") FROM stdin;
3d1d1c6c-3b96-4fb7-a44e-72996d9ae07e	604239e2-269e-4b2c-8d1e-7df5c84249dc	8ce20828-2110-4a57-8894-d9708721ca3a	INCOME	1500	Venta lunes	2026-05-17 01:07:05.73	CHAT	\N	2026-05-17 01:07:05.73
aea15875-86e1-4c26-8b9f-9c9ce2d4bd58	604239e2-269e-4b2c-8d1e-7df5c84249dc	8ce20828-2110-4a57-8894-d9708721ca3a	INCOME	2200	Venta martes	2026-05-17 01:07:05.741	VOICE	\N	2026-05-17 01:07:05.741
41b23572-7239-4a6f-9d75-ef1010d7c0d3	604239e2-269e-4b2c-8d1e-7df5c84249dc	8ce20828-2110-4a57-8894-d9708721ca3a	INCOME	1800	Venta miercoles	2026-05-17 01:07:05.752	MANUAL	\N	2026-05-17 01:07:05.752
867174dc-12a4-4b8e-939e-2540490d568e	604239e2-269e-4b2c-8d1e-7df5c84249dc	7d4c2084-bbc6-4ce8-bd3d-e4ef83b3c886	EXPENSE	800	Compra verduras	2026-05-17 01:07:05.759	CHAT	\N	2026-05-17 01:07:05.759
2f4ea88f-3871-4cc9-b551-d32f9468f28f	604239e2-269e-4b2c-8d1e-7df5c84249dc	7d4c2084-bbc6-4ce8-bd3d-e4ef83b3c886	EXPENSE	450	Compra carne	2026-05-17 01:07:05.766	MANUAL	\N	2026-05-17 01:07:05.766
d935a741-395e-45b3-bb0d-781bb6ddefe2	604239e2-269e-4b2c-8d1e-7df5c84249dc	4ef49235-a534-49b5-ba56-ac6a79708665	EXPENSE	200	Pago luz	2026-05-17 01:07:05.772	MANUAL	\N	2026-05-17 01:07:05.772
f01c8586-031c-4ba4-818d-ec1cacc27ed3	604239e2-269e-4b2c-8d1e-7df5c84249dc	4ef49235-a534-49b5-ba56-ac6a79708665	EXPENSE	150	Pago agua	2026-05-17 01:07:05.778	MANUAL	\N	2026-05-17 01:07:05.778
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, "passwordHash", "businessType", "targetMarginPct", "createdAt", "updatedAt") FROM stdin;
604239e2-269e-4b2c-8d1e-7df5c84249dc	Carlos Mamani	carlos@test.com	$2a$10$abcdefghijklmnopqrstuuABCDEFGHIJKLMNOPQRSTUVWXYZ12	restaurant	40	2026-05-17 01:07:05.623	2026-05-17 01:07:05.623
\.


--
-- Name: monthly_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monthly_summaries_id_seq', 1, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: monthly_summaries monthly_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_summaries
    ADD CONSTRAINT monthly_summaries_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_messages_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "agent_messages_userId_createdAt_idx" ON public.agent_messages USING btree ("userId", "createdAt");


--
-- Name: alerts_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "alerts_userId_idx" ON public.alerts USING btree ("userId");


--
-- Name: categories_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "categories_userId_idx" ON public.categories USING btree ("userId");


--
-- Name: idx_alerts_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_unread ON public.alerts USING btree ("isRead");


--
-- Name: idx_monthly_year_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_monthly_year_month ON public.monthly_summaries USING btree (year, month);


--
-- Name: idx_tx_user_type_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tx_user_type_date ON public.transactions USING btree ("userId", type, date);


--
-- Name: monthly_summaries_userId_categoryId_year_month_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "monthly_summaries_userId_categoryId_year_month_key" ON public.monthly_summaries USING btree ("userId", "categoryId", year, month);


--
-- Name: recommendations_userId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "recommendations_userId_status_idx" ON public.recommendations USING btree ("userId", status);


--
-- Name: transactions_categoryId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "transactions_categoryId_date_idx" ON public.transactions USING btree ("categoryId", date);


--
-- Name: transactions_userId_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "transactions_userId_date_idx" ON public.transactions USING btree ("userId", date);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: transactions trigger_refresh_views; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_refresh_views AFTER INSERT OR DELETE OR UPDATE ON public.transactions FOR EACH STATEMENT EXECUTE FUNCTION public.refresh_materialized_views();


--
-- Name: agent_messages agent_messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT "agent_messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: alerts alerts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT "alerts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories categories_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monthly_summaries monthly_summaries_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_summaries
    ADD CONSTRAINT "monthly_summaries_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: monthly_summaries monthly_summaries_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monthly_summaries
    ADD CONSTRAINT "monthly_summaries_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recommendations recommendations_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT "recommendations_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: recommendations recommendations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT "recommendations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transactions transactions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT "transactions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: alerts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

--
-- Name: monthly_summaries; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.monthly_summaries ENABLE ROW LEVEL SECURITY;

--
-- Name: recommendations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: alerts user_alerts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_alerts ON public.alerts USING (("userId" = current_setting('app.current_user_id'::text)));


--
-- Name: categories user_categories; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_categories ON public.categories USING (("userId" = current_setting('app.current_user_id'::text)));


--
-- Name: monthly_summaries user_monthly; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_monthly ON public.monthly_summaries USING (("userId" = current_setting('app.current_user_id'::text)));


--
-- Name: recommendations user_recommendations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recommendations ON public.recommendations USING (("userId" = current_setting('app.current_user_id'::text)));


--
-- Name: transactions user_transactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_transactions ON public.transactions USING (("userId" = current_setting('app.current_user_id'::text)));


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT USAGE ON SCHEMA public TO app_readonly;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public._prisma_migrations TO app_user;
GRANT SELECT ON TABLE public._prisma_migrations TO app_readonly;


--
-- Name: TABLE agent_messages; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.agent_messages TO app_user;
GRANT SELECT ON TABLE public.agent_messages TO app_readonly;


--
-- Name: TABLE alerts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.alerts TO app_user;
GRANT SELECT ON TABLE public.alerts TO app_readonly;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.categories TO app_user;
GRANT SELECT ON TABLE public.categories TO app_readonly;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.transactions TO app_user;
GRANT SELECT ON TABLE public.transactions TO app_readonly;


--
-- Name: TABLE gastos_por_categoria; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.gastos_por_categoria TO app_user;
GRANT SELECT ON TABLE public.gastos_por_categoria TO app_readonly;


--
-- Name: TABLE monthly_summaries; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.monthly_summaries TO app_user;
GRANT SELECT ON TABLE public.monthly_summaries TO app_readonly;


--
-- Name: TABLE recommendations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.recommendations TO app_user;
GRANT SELECT ON TABLE public.recommendations TO app_readonly;


--
-- Name: TABLE resumen_financiero_mensual; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.resumen_financiero_mensual TO app_user;
GRANT SELECT ON TABLE public.resumen_financiero_mensual TO app_readonly;


--
-- Name: TABLE tendencia_semanal; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.tendencia_semanal TO app_user;
GRANT SELECT ON TABLE public.tendencia_semanal TO app_readonly;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.users TO app_user;
GRANT SELECT ON TABLE public.users TO app_readonly;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,UPDATE ON TABLES TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES TO app_readonly;


--
-- Name: gastos_por_categoria; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.gastos_por_categoria;


--
-- Name: resumen_financiero_mensual; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.resumen_financiero_mensual;


--
-- Name: tendencia_semanal; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.tendencia_semanal;


--
-- PostgreSQL database dump complete
--

\unrestrict RokXQnUIaazLwF9LVPRDRafk4qKjyo58IqkPohyDnN6lRQv3G9c9R0CRETOpWMa

